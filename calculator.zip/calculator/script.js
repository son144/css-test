    let display = document.getElementById('display');
    let numbers = document.querySelectorAll('.number');
    let operators = document.querySelectorAll('.operator');
    let clearButton = document.getElementById('clear');
    let calculateButton = document.getElementById('calculate');

    numbers.forEach(function(button) {
        button.addEventListener('click', function() {
            display.value += button.textContent;
        });
    });

    operators.forEach(function(button) {
        button.addEventListener('click', function() {
            display.value += button.textContent;
        });
    });

    clearButton.addEventListener('click', function() {
        display.value = '';
    });

    calculateButton.addEventListener('click', function() {
        try {
            display.value = eval(display.value);
        } catch (e) {
            display.value = 'Error';
        }
    });
